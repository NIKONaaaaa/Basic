﻿namespace Farm
{
    using System;
    public class Cat : Animal
    {
        public Cat()
        {

        }

        public void Meow()
        {
            Console.WriteLine("meowing...");
        }
    }
}