﻿namespace Farm
{
    using System;
    public class Dog : Animal
    {
        public Dog()
        {

        }

        public void Bark()
        {
            Console.WriteLine("barking...");
        }
    }
}