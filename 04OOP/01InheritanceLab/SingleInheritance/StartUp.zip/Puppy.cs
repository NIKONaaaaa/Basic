﻿namespace Farm
{
    using System;
    public class Puppy : Dog
    {
        public Puppy()
        {

        }

        public void Weep()
        {
            Console.WriteLine("weeping...");
        }
    }
}