﻿namespace CustomStack
{
    using System;
    public class StartUp
    {
        static void Main()
        {
            Console.WriteLine("Hello World!");
        }
    }
}