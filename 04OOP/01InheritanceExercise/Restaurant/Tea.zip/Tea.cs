﻿namespace Restaurant
{
    public class Tea : HotBeverage
    {
        public Tea(string name, decimal price, double milliliters, double caffeine) : base(name, price, milliliters)
        {

        }
    }
}