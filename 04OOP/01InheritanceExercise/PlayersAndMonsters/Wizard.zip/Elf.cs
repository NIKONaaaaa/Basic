﻿namespace PlayersAndMonsters
{
    public class Elf : Hero
    {
        public Elf(string name, int level) : base(name, level)
        {

        }
    }
}